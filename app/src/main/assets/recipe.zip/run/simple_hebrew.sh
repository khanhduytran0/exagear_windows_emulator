#!/bin/bash
eval LC_ALL=he_IL.utf8 "$@" -w
